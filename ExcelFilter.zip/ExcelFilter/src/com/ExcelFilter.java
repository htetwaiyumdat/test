package com;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class ExcelFilter {
    public static void main (String[] args) throws ParseException {
        // Define the path to your Excel file
    	// Access file server directory via map network drive 
        String excelFilePath = "Z:\\Template.xlsx";

        try (FileInputStream fis = new FileInputStream(excelFilePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            // Assuming you're working with the first sheet (index 0)
            Sheet sheet = workbook.getSheetAt(0);

            // Create a new workbook for filtered data
            Workbook filteredWorkbook = new XSSFWorkbook();
            Sheet filteredSheet = filteredWorkbook.createSheet("Filtered Data");

            // Define the keyword you want to filter for
            String keyword = "zabbix";

            int rowIndex = 0; // Track the row index for the filtered sheet

         // Create a date formatter for comparing dates in column J
            // SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
             SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy年MM月d日");
             SimpleDateFormat outputFormat = new SimpleDateFormat("yyyyMMdd");

            // Get the current date and calculate the date 14 days from now
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_MONTH, 14);
            Date endDate1 = calendar.getTime();
            System.out.println(endDate1);
            String endDate = outputFormat.format(endDate1);
            System.out.println(endDate);
            // Iterate through each row in the original sheet
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                // Assuming you want to filter based on column C (index 2)
                Cell keywordCell = row.getCell(2); // Column C (index 2)
                System.out.println(keywordCell);
                if (keywordCell == null) {break;}
                
                // Assuming you want to filter based on column J (index 9)
                Cell dateCellOrg = row.getCell(9); // Column J (index 9)
                String dateCell1 = dateCellOrg.getStringCellValue();
                Date date = inputFormat.parse(dateCell1);
                System.out.println(date);
                String dateString = outputFormat.format(date);
                dateCellOrg.setCellValue(dateString);

                if (keywordCell != null && keywordCell.getCellType() == CellType.STRING &&
                    date != null) {

                    String cellValue = keywordCell.getStringCellValue();

                    // Check if the cell value contains the keyword
                    if (cellValue.toLowerCase().contains(keyword.toLowerCase()) &&
                    	dateString.equals(endDate)) {
                        // Create a new row in the filtered sheet
                        Row filteredRow = filteredSheet.createRow(rowIndex++);

                        // Get the value from column B (index 1)
                        Cell columnBCell = row.getCell(1); // Column B (index 1)

                        // Copy the value from column B to the filtered sheet
                        if (columnBCell != null) {
                            Cell filteredCell = filteredRow.createCell(0); // New column in filtered sheet
                            filteredCell.setCellValue(columnBCell.getStringCellValue());
                        }
                    }
                }
            }

            // Save the filtered workbook to a new file
            //try (FileOutputStream fos = new FileOutputStream("D:\\MODOS\\Filtered_Output.xlsx")) {
            try (FileOutputStream fos = new FileOutputStream("Z:\\Filtered_Output.xlsx")) {
                filteredWorkbook.write(fos);
            }

            System.out.println("Filtering completed. Filtered data saved to Filtered_Output.xlsx");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
